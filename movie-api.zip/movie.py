import csv

with open("movies.csv") as f:
    reader = csv.reader(f)
    data = list(reader)

    all_movies = data[1:]
    headers = data[0]

headers.append("poster_link")

with open("final.csv", "a+") as f:
    csv_writer = csv.writer(f)
    csv_writer.writerow(headers)

with open("movie_links.csv") as f:
    csv_reader = csv.reader(f)
    data = list(reader)

    all_links = data[1:]
    headers = data[0]